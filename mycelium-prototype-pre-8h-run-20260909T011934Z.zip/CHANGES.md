# CHANGES

## 2026-09-08 — execução do plano para crescimento composto / rumo a exponencial

Foi implementada uma nova camada arquitetural voltada não só a throughput, mas a **composição de capacidade** ao longo do tempo.

### 1. Macro staging e promoção mais forte

O projeto agora possui uma etapa intermediária entre descoberta local e primitiva global:

- `macro_staging` persistido no estado
- registro por macro de:
  - família de origem
  - suporte entre famílias
  - `transfer_gain`
  - `compression_gain`
  - `reuse_count`
  - `last_seen_round`
- promoção automática para `macro_library` quando os limiares são atendidos
- aposentadoria de macros fracas/estagnadas

### 2. Nichos comportamentais e diversidade explícita

A avaliação passou a registrar assinatura comportamental por probes canônicos.

Novas capacidades:

- contagem de nichos ativos
- entropia de diversidade
- bônus leve de novidade para soluções menos redundantes
- viés de extinção um pouco menos cego à redundância global

### 3. Desafios composicionais e frontier archive

O gerador de desafios agora pode produzir desafios `compositional` além dos desafios padrão.

Também foi adicionado um `frontier_archive` persistido com classificação recente de desafios:

- `dominated`
- `frontier`
- `impossible`

Além disso, o engine agora mede `frontier_learning_progress` em janela móvel.

### 4. Política de mutação mais rica

O breeding ganhou uma política de mutação com operadores mais variados:

- mutação padrão estrutural
- `gene_splice`
- injeção de macro
- `shrink` estrutural

### 5. Expansão do self-improve

O modo `self-improve` passou a explorar não só backend e cadência de persistência, mas também parâmetros da política de busca, incluindo:

- `novelty_weight`
- `macro_potential_weight`
- `transfer_weight`
- `macro_support_threshold`
- `macro_transfer_threshold`
- `compositional_challenge_rate`
- `gene_splice_rate`
- `shrink_mutation_rate`

### 6. Persistência e métricas do estado

O formato do estado foi atualizado para `format = 4`, preservando compatibilidade de leitura com formatos anteriores.

Novos campos persistidos incluem:

- `macro_staging`
- `frontier_archive`
- métricas extras por rodada, como:
  - `active_niches`
  - `diversity_entropy`
  - `macro_transfer_mean`
  - `frontier_learning_progress`
  - `frontier_status_counts`

### 7. Validação desta onda

- suíte de testes: **17 testes passando**
- benchmark de throughput isolado do perfil default: **~108.83 rounds/s** em uma execução observada
- benchmark multi-seed do perfil default: **~100.75 rounds/s** observado
- benchmark de 120 rounds com o novo regime: **~86.73 rounds/s** observado, com:
  - `macro_library_count = 2`
  - `macro_staging_count = 12`
  - `frontier_difficulty = 4`
  - regime ainda classificado como `sublinear`

Leitura honesta:

- a arquitetura para composição de capacidade foi implementada;
- já há promoção real de macros e desafios composicionais em execução;
- **ainda não foi demonstrado crescimento exponencial sustentado**;
- o resultado atual é melhor descrito como um passo viável em direção a crescimento composto, ainda em regime sublinear/linear dependendo da janela.

---

## 2026-09-08 — persistência binária opcional e daemon contínuo de auto melhoria

Foi implementada uma quarta onda focada em **overhead de persistência** e em **auto melhoria contínua controlável**.

### Persistência opcional por backend

O projeto agora aceita dois backends de persistência:

- `json` — continua sendo o default por legibilidade e compatibilidade
- `pickle` — backend binário opcional para reduzir overhead quando há flush/checkpoint frequente

Mudanças principais:

- `Config.persistence_backend` adicionado e validado com `{"json", "pickle"}`
- CLI comum ganhou `--persistence-backend {json,pickle}`
- estado persistido como `state.json` ou `state.pkl`
- checkpoints persistidos como `.json` ou `.pkl`
- rollback passou a resolver automaticamente ambos os formatos
- gravação de payloads passou a usar escrita em arquivo temporário + `os.replace(...)`
- loader de estado agora faz fallback entre backends quando o arquivo esperado não existe

Leitura honesta do benchmark desta sessão:

- no benchmark simples por perfil, o default em `json` permaneceu levemente melhor e ficou em **~96,90 rounds/s**
- o perfil `default_binary_optional` com `pickle` ficou em **~89,83 rounds/s**
- em carga de persistência agressiva (`state_save_every=1`, `checkpoint_every=1`), `pickle` reduziu o overhead de forma clara:
  - `json`: **~49,13 rounds/s** na média de 5 execuções
  - `pickle`: **~82,64 rounds/s** na média de 5 execuções

Conclusão operacional:

- `pickle` foi mantido como **opção** em vez de virar default universal;
- o modo `self-improve` agora pode testá-lo e adotá-lo apenas quando o guarda comprovar ganho real no cenário medido.

### Daemon/loop contínuo de self-improvement

Foi adicionado o comando:

```bash
python -m mycelium self-improve-daemon
```

Capacidades novas:

- laço contínuo de auto melhoria
- parada pelo kill-switch já existente no `state_dir`
- parada por `--time-budget-seconds`
- parada por `--max-cycles`
- espera configurável entre ciclos com `--sleep-seconds`
- arquivo de status em `.mycelium_self_improve/daemon.status.json`

O modo `self-improve` também passou a considerar candidatos que trocam:

- backend de persistência
- cadência de `checkpoint_every`
- cadência de `state_save_every`

### Validação executada após as mudanças

Suíte de testes:

```bash
python -m unittest discover -s tests -v
```

Resultado validado nesta sessão:

- **17 testes passando**

Cobertura nova confirmada:

- round-trip de estado em `pickle`
- rollback usando checkpoint em `pickle`
- geração de candidatos que inclui `persistence_backend`
- escrita de `daemon.status.json`

Benchmarks rerodados nesta sessão:

```bash
python examples/benchmark_runtime.py
python examples/benchmark_quality.py
```

Resultado relevante:

- `default`: **~93,91 rounds/s** na média multi-seed com qualidade preservada
- `quality_reference`: **~52,70 rounds/s**
- o perfil default continuou acima da meta operacional de **~89 rounds/s**
- métricas multi-seed observadas do default permaneceram em linha com a calibração anterior:
  - `best_score_mean`: **~3,62**
  - `best_exact_rate_mean`: **~0,45**
  - `solved_by_best_mean`: **~1,2**
  - `capability_signal_mean`: **~3,25**

---

## 2026-09-08 — consolidação do protótipo, 3 ondas de otimização e modo de auto melhoria

Este arquivo consolida o histórico implementado no protótipo base do **MYCELIUM**, incluindo a fase final orientada ao alvo operacional de **~89 rounds/s** por geração e a adição de um modo explícito de **auto melhoria com guarda anti-regressão**.

---

## 1. Fundação do repositório

Foi criada a base pronta para GitHub com:

- `pyproject.toml`
- `README.md`
- `LICENSE`
- `.gitignore`
- `.github/workflows/ci.yml`
- pacote `mycelium/`
- `docs/ARCHITECTURE.md`
- `docs/PERFORMANCE.md`
- suíte inicial de testes

Objetivo desta fase:

- transformar `PROMPT.md` em uma base executável, versionável e publicável.

---

## 2. Implementação funcional do protótipo

### 2.1 DSL evolutiva

Implementado um núcleo de programas simbólicos em árvore (`Node`) com:

- terminais: `input`, `const`, `macro`
- unários: `neg`, `abs`, `inc`, `dec`, `square`
- binários: `add`, `sub`, `mul`, `max`, `min`, `mod`

Também foram adicionados:

- geração procedural de árvores
- mutação estrutural
- crossover
- extração de subárvores/motivos
- biblioteca global de macros

### 2.2 Motor evolutivo

O engine passou a cobrir:

- torneio ímpar
- fase seletiva inspirada em `i`
- vigor de linhagem inspirado em `e`
- clima com modulação leve de `π` e `1/2.967`
- extinção familiar
- diáspora dos 7
- reposição por família fresca
- fusão entre extremos
- gene bank por família
- macro library global

### 2.3 Personagens

Implementados:

- **Artista**
- **Clérigo**
- **Ladrão**

### 2.4 Desafios black-box

Criado `ChallengeFactory` com:

- oráculos ocultos procedurais
- entrada apenas por pares entrada→saída
- filtro de não-trivialidade semântica
- dificuldade acoplada à capacidade demonstrada

### 2.5 Persistência operacional

Adicionados:

- `state.json`
- `audit.log.jsonl`
- checkpoints
- rollback
- kill-switch por arquivo
- retomada após reinício

### 2.6 Modo aceleração

Criado suporte para:

```bash
python -m mycelium accelerate --target self
python -m mycelium accelerate --target examples/accelerate_target.py
```

com:

- benchmark determinístico
- validação de equivalência
- aplicação do resultado de volta ao código-fonte real

---

## 3. Primeira onda de otimização

Objetivo:

- sair do MVP funcional lento e reduzir o custo óbvio do caminho quente.

### Mudanças

- executor da DSL passou para modelo compilado stack-based
- `Node` ganhou cache de `count_nodes`, `depth`, `render` e complexidade
- `deepcopy()` foi removido do caminho crítico
- mutação e crossover ficaram mais leves
- oráculo de desafio passou a ser compilado uma vez e reutilizado
- JSON deixou de ser salvo com indentação

### Resultado observado

- base inicial funcional: **~9,06 rounds/s**
- após a primeira onda: **~22,48 rounds/s**

Ganho:

- **~2,48x**

---

## 4. Segunda onda de otimização

Objetivo:

- atacar o custo de persistência e reduzir overhead de serialização.

### Mudanças

- estado compacto versionado (`format = 3`)
- árvores serializadas em forma curta
- famílias e organismos serializados em listas compactas
- `graveyard` compactado
- `metrics_history` empacotado em arrays posicionais
- `check_circular=False`
- `separators=(",", ":")`
- `state_save_every` adicionado ao config/CLI
- flush final garantido mesmo quando `state_save_every > 1`

### Compatibilidade

O loader passou a aceitar:

- estado legado verboso
- formato compacto anterior (`format = 2`)
- formato compacto atual (`format = 3`)

### Redução de payload observada

Em uma amostra desta sessão:

- payload verboso: **72.411 bytes**
- payload compacto: **10.365 bytes**
- redução: **85,69%**

### Resultado observado

- perfil padrão da fase: **~31,5 rounds/s**
- perfil rápido configurado: **~122–124 rounds/s**

Ganho consolidado contra a base inicial no perfil padrão:

- **~3,48x**

---

## 5. Terceira onda de otimização — alvo explícito de ~89 rounds/s

Objetivo desta fase final:

- atingir cerca de **89 rounds/s por geração**
- mantendo ou elevando a qualidade média observada
- sem reduzir o benchmark de tarefas para um cenário artificialmente fácil

### 5.1 Scoring em lote dentro do executor

A maior mudança foi mover a avaliação de datasets para dentro do `ProgramExecutor`.

Novos caminhos quentes:

- `score_pairs()`
- `score_pairs_limit()`

Efeitos:

- menos chamadas Python por amostra
- menos overhead de ida/volta entre engine e executor
- stack reutilizada durante o scoring de um dataset

### 5.2 Reuso de stack por dataset

A stack interna do executor passa a ser alocada uma vez por scoring de dataset e reaproveitada entre pares.

Efeitos:

- menos alocação temporária
- menor pressão no coletor de lixo
- custo menor por avaliação

### 5.3 Cache de executores entre rodadas

O cache de executores deixou de ser apenas por rodada e passou a ficar aquecido no próprio engine.

Também foi adicionado um teto simples de cache para evitar crescimento indefinido.

### 5.4 Avaliação adaptativa em duas fases

Foi implementada uma política de triagem + rescore completo:

1. todos os organismos passam por uma triagem mais barata em subconjuntos dos desafios;
2. por família, apenas os melhores na triagem e um pequeno explorador aleatório recebem avaliação integral.

Parâmetros adicionados:

- `probe_challenges`
- `probe_train_cases`
- `probe_test_cases`
- `full_rescore_top_k`
- `full_rescore_random_k`

Motivação:

- concentrar compute nos candidatos que mais afetam a seleção final;
- acelerar sem simplesmente reduzir o problema.

### 5.5 Recalibração dos defaults

Os defaults do projeto foram ajustados para um perfil que bate a meta operacional observada no sandbox:

- `family_count=7`
- `family_size=11`
- `challenges_per_round=3`
- `train_cases=8`
- `test_cases=16`
- `checkpoint_every=10`
- `state_save_every=10`
- `probe_challenges=2`
- `probe_train_cases=2`
- `probe_test_cases=4`
- `full_rescore_top_k=4`
- `full_rescore_random_k=1`

Importante:

- o benchmark de desafios permaneceu em `3 x (8 treino + 16 teste)` no perfil default;
- a meta foi atingida principalmente por melhor alocação de compute e menor overhead estrutural.

---

## 6. Benchmarks finais observados nesta sessão

### 6.1 Benchmark de throughput por perfil

Comando:

```bash
python examples/benchmark_runtime.py
```

Resultado observado nesta sessão:

#### Perfil `default`

- **~94 rounds/s**

#### Perfil `quality_reference`

- **~55 rounds/s**

#### Perfil `turbo`

- **~132–137 rounds/s**

### 6.2 Benchmark multi-seed de velocidade x qualidade

Comando:

```bash
python examples/benchmark_quality.py
```

Seeds usadas nesta sessão:

- `101, 103, 107, 109, 113`

#### `quality_reference`

- throughput médio: **~51,97 rounds/s**
- `best_score_mean`: **~2,95**
- `frontier_difficulty_mean`: **~2,6**
- `best_exact_rate_mean`: **~0,354**
- `solved_by_best_mean`: **~0,6**
- `capability_signal_mean`: **~3,154**

#### `default`

- throughput médio: **~90,74 rounds/s**
- `best_score_mean`: **~3,62**
- `frontier_difficulty_mean`: **~2,4**
- `best_exact_rate_mean`: **~0,45**
- `solved_by_best_mean`: **~1,2**
- `capability_signal_mean`: **~3,25**

### Leitura honesta

No conjunto medido nesta sessão, o perfil default:

- **atingiu a meta de ~89 rounds/s**;
- **melhorou** `best_score_mean`;
- **melhorou** `best_exact_rate_mean`;
- **melhorou** `solved_by_best_mean`;
- **melhorou** `capability_signal_mean`.

Houve leve queda em `frontier_difficulty_mean`, então a conclusão correta é:

> o default atual entrega um compromisso melhor de velocidade/qualidade no benchmark observado, não uma dominância absoluta em toda métrica isolada.

---

## 7. Modo de auto melhoria com guarda anti-regressão

Foi adicionado o comando:

```bash
python -m mycelium self-improve --seed 101 --state-dir .mycelium_state --cycles 1 --rounds-per-cycle 20
```

### 7.1 O que ele faz

Em cada ciclo, o modo:

1. executa rounds normais de evolução;
2. mede o baseline atual do próprio projeto;
3. gera candidatos automáticos de tuning;
4. compara baseline e candidato com as mesmas seeds;
5. aplica a mudança só se o guarda aprovar;
6. roda a suíte de testes antes de consolidar a alteração.

### 7.2 O que ele pode auto melhorar neste MVP

- `mycelium/generated/active_variants.py`
- `mycelium/generated/default_profile.py`

Ou seja, o projeto passa a conseguir recalibrar automaticamente:

- a variante ativa interna;
- os defaults de execução.

### 7.3 Guarda anti-regressão

Foi implementado um guarda explícito sobre:

- `rounds_per_second_mean`
- `best_score_mean`
- `best_exact_rate_mean`
- `solved_by_best_mean`
- `capability_signal_mean`
- `frontier_difficulty_mean`

Comportamento:

- exige ganho mínimo de throughput;
- bloqueia queda além das tolerâncias configuradas;
- reverte a alteração se a suíte de testes falhar.

Defaults atuais do guarda:

- benchmark de `30` rodadas por candidato;
- seeds `101,103,107,109,113`;
- tolerância zero para `best_score_mean`, `best_exact_rate_mean`, `solved_by_best_mean` e `capability_signal_mean`;
- tolerância pequena para `frontier_difficulty_mean`.

### 7.4 Artefatos e dependências de segurança do modo

Foram adicionados ou integrados:

- `mycelium/self_improve.py`
- `mycelium/runtime_profile.py`
- `mycelium/generated/default_profile.py`
- `docs/SELF_IMPROVEMENT.md`
- relatórios em `.mycelium_self_improve/`
- suíte de testes como trava final

### 7.5 Paralelização do guarda

A busca do guarda por candidatos passou a rodar em paralelo por processos.

Estratégia adotada:

- cada combinação de `perfil x variante x seed` vira uma tarefa isolada;
- as tarefas são executadas por `ProcessPoolExecutor`;
- os resultados são agregados no processo principal antes da decisão final.

Garantias preservadas:

- mesmas seeds entre baseline e candidato;
- mesmas métricas protegidas;
- mesma política de aceitação/rejeição;
- isolamento natural entre execuções de benchmark.

Parâmetro novo:

- `--guard-workers`

### 7.6 Execução por orçamento de tempo

O modo `self-improve` passou a aceitar execução com janela temporal fixa.

Parâmetro novo:

- `--time-budget-seconds`

Com isso, o processo pode ficar em auto melhoria contínua por uma duração controlada e ainda encerrar de forma limpa com relatório final.

### 7.7 Ajustes para evitar regressão causada pela própria suíte

`tests/test_acceleration.py` foi ajustado para usar `accelerate_self(..., apply=False)`.

Motivo:

- impedir que a própria suíte mude `active_variants.py` durante a validação;
- evitar regressão acidental do estado configurado do projeto.

---

## 8. CLI e ergonomia de tuning

O comando `run` passou a expor mais knobs de performance e qualidade:

- `--challenges-per-round`
- `--train-cases`
- `--test-cases`
- `--initial-difficulty`
- `--max-program-depth`
- `--max-program-nodes`
- `--max-abs-value`
- `--max-eval-steps`
- `--max-macros`
- `--checkpoint-every`
- `--state-save-every`
- `--probe-challenges`
- `--probe-train-cases`
- `--probe-test-cases`
- `--full-rescore-top-k`
- `--full-rescore-random-k`
- `--climate-weight`

O comando `self-improve` também passou a expor controles do guarda:

- `--benchmark-rounds`
- `--benchmark-seeds`
- `--guard-workers`
- `--time-budget-seconds`
- `--min-speedup-ratio`
- `--max-best-score-drop`
- `--max-exact-rate-drop`
- `--max-solved-drop`
- `--max-capability-drop`
- `--max-frontier-drop`
- `--skip-tests`
- `--project-root`

---

## 9. Benchmarks e exemplos adicionados

Arquivos adicionados ou ampliados:

- `examples/accelerate_target.py`
- `examples/benchmark_runtime.py`
- `examples/benchmark_quality.py`

Esses scripts agora permitem:

- medir throughput por perfil
- comparar perfis de velocidade x qualidade em múltiplas seeds
- reproduzir a calibração do default

---

## 10. Testes adicionados/validados

Suíte atual:

- `tests/test_prime.py`
- `tests/test_smoke.py`
- `tests/test_acceleration.py`
- `tests/test_dsl.py`
- `tests/test_state.py`
- `tests/test_self_improve.py`

Cobertura validada nesta sessão:

- equivalência da API da DSL com o executor compilado
- funcionamento do modo aceleração
- persistência do estado
- formato compacto do `state.json`
- flush final com `state_save_every > 1`
- guarda anti-regressão
- geração de candidatos dentro dos limites
- emissão de relatório no modo `self-improve`
- respeito ao `time_budget_seconds`

Resultado atual:

- **14 testes passando**

---

## 11. Arquivos principais alterados

- `mycelium/dsl.py`
- `mycelium/engine.py`
- `mycelium/challenge.py`
- `mycelium/model.py`
- `mycelium/config.py`
- `mycelium/state.py`
- `mycelium/audit.py`
- `mycelium/acceleration.py`
- `mycelium/__main__.py`
- `mycelium/self_improve.py`
- `mycelium/runtime_profile.py`
- `mycelium/generated/default_profile.py`
- `README.md`
- `docs/ARCHITECTURE.md`
- `docs/PERFORMANCE.md`
- `docs/SELF_IMPROVEMENT.md`
- `examples/benchmark_runtime.py`
- `examples/benchmark_quality.py`
- `tests/test_acceleration.py`
- `tests/test_dsl.py`
- `tests/test_self_improve.py`
- `tests/test_state.py`
- `.gitignore`

---

## 12. Estado atual do protótipo

A base agora está:

- funcional
- testada
- pronta para GitHub
- com defaults calibrados para ~89 rounds/s
- com benchmark reproduzível de throughput
- com benchmark reproduzível de velocidade x qualidade
- com persistência mais barata
- com seleção adaptativa que preserva qualidade média no cenário medido

---

## 13. Próximas otimizações recomendadas

1. perfis nativos no CLI (`default`, `quality`, `turbo`);
2. checkpoints delta/incrementais;
3. paralelização por família/processo;
4. autotuning adaptativo da política de triagem;
5. redução adicional do custo de mutação/crossover em alta diversidade;
6. seleção automática mais inteligente do backend de persistência por regime de workload.
