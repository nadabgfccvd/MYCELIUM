# MYCELIUM — protótipo base

Protótipo inicial em **Python puro** para materializar a especificação do arquivo `PROMPT.md` em uma base concreta, versionável e pronta para subir no GitHub.

> Estado atual: **MVP arquitetural funcional otimizado para throughput**.
> 
> Ele já roda, persiste estado em disco, evolui programas simbólicos, gera desafios procedurais black-box, aplica regras populacionais inspiradas na especificação e possui um modo inicial de auto-aceleração com verificação de equivalência.
> 
> Nesta iteração, o caminho quente foi otimizado com avaliação em lote no executor da DSL, cache de executores entre rodadas, persistência compacta e seleção adaptativa em duas fases para bater a meta operacional de ~89 rounds/s sem derrubar a qualidade média observada.

## O que este protótipo cobre

- **Sem LLM**: nenhuma chamada de modelo, nenhuma dependência de IA generativa para decisão.
- **Sementes primas**: a seed principal é validada como número primo.
- **Desafios aleatórios e infinitos**: cada round gera oráculos ocultos e entrega apenas pares entrada→saída, incluindo uma faixa composicional para pressionar recombinação de capacidades.
- **Estrutura evolutiva**: os indivíduos são árvores de programas em uma DSL inteira e mutam estruturalmente.
- **Transferência horizontal**: subárvores úteis entram em `gene_bank`, passam por `macro_staging` e podem ser promovidas para `macro_library`.
- **Famílias + extinção + diáspora dos 7**: uma família é extinta por rodada, 7 sobrevivem e são redistribuídos.
- **Clima, fase por `i`, vigor por `e`**: todos modelados como moduladores reais da seleção.
- **Personagens periódicos**: ladrão, clérigo e artista já perturbam a população.
- **Persistência configurável**: `state.json` ou `state.pkl`, checkpoints `.json` ou `.pkl`, log append-only, rollback e kill-switch por arquivo.
- **Avaliação adaptativa em duas fases**: triagem barata + rescore completo de candidatos promissores.
- **Nichos comportamentais**: assinatura por probes, bônus leve de novidade e entropia de diversidade.
- **Acumulação composicional**: `macro_staging`, promoção para `macro_library`, ganho de compressão e transferência.
- **Modo de auto melhoria**: tuning automático do próprio projeto com guarda anti-regressão.
- **Modo daemon de auto melhoria**: loop contínuo com status persistido e parada limpa por kill-switch.
- **Modo aceleração**: benchmark determinístico, verificação de equivalência e aplicação da escolha de volta ao código.
- **Relatório honesto de crescimento**: classifica o regime observado como exponencial, linear, sublinear ou estagnado.

## O que ele ainda não tenta resolver por completo

Este repositório é uma **base séria**, não a versão final da tese.

Ainda faltam, para um sistema de pesquisa mais agressivo:

- sandbox por processo isolado do SO;
- metas multiobjetivo mais sofisticadas;
- aceleração genérica de projetos arbitrários além do contrato Python atual;
- comparação estatística pareada entre regras em muitas seeds;
- mutações semânticas mais profundas;
- mecanismos mais fortes para sustentar crescimento realmente exponencial por longos horizontes.

## Estrutura do repositório

```text
mycelium-prototype/
├─ mycelium/
│  ├─ __main__.py
│  ├─ acceleration.py
│  ├─ audit.py
│  ├─ challenge.py
│  ├─ config.py
│  ├─ dsl.py
│  ├─ engine.py
│  ├─ model.py
│  ├─ prime.py
│  ├─ runtime_profile.py
│  ├─ self_improve.py
│  ├─ state.py
│  └─ generated/
│     ├─ active_variants.py
│     └─ default_profile.py
├─ docs/
│  ├─ ARCHITECTURE.md
│  ├─ PERFORMANCE.md
│  └─ SELF_IMPROVEMENT.md
├─ examples/
│  ├─ accelerate_target.py
│  ├─ benchmark_quality.py
│  └─ benchmark_runtime.py
├─ tests/
├─ CHANGES.md
├─ README.md
└─ pyproject.toml
```

## Requisitos

- Python **3.11+**
- Nenhuma dependência externa obrigatória

## Como rodar

### 1) Inicializar o estado

```bash
python -m mycelium init --seed 101 --state-dir .mycelium_state
```

> `101` é primo. Seeds não-primas falham por design.

### 2) Rodar rounds de melhoria

```bash
python -m mycelium run --seed 101 --state-dir .mycelium_state --rounds 20
```

> Os defaults atuais já estão afinados para o alvo operacional de aproximadamente **89 rounds/s** mantendo a configuração de desafios em `3 x (8 treino + 16 teste)`.

### 2.1) Rodar em configuração de referência de qualidade

```bash
python -m mycelium run \
  --seed 101 \
  --state-dir .mycelium_state \
  --rounds 100 \
  --family-count 9 \
  --family-size 15 \
  --checkpoint-every 10 \
  --state-save-every 10 \
  --probe-train-cases 3 \
  --probe-test-cases 6 \
  --full-rescore-top-k 6 \
  --full-rescore-random-k 1
```

### 2.2) Rodar em configuração turbo

```bash
python -m mycelium run \
  --seed 101 \
  --state-dir .mycelium_state \
  --rounds 100 \
  --family-count 7 \
  --family-size 10 \
  --challenges-per-round 2 \
  --train-cases 6 \
  --test-cases 10 \
  --max-program-depth 4 \
  --max-program-nodes 31 \
  --checkpoint-every 20 \
  --state-save-every 10 \
  --probe-train-cases 2 \
  --probe-test-cases 4 \
  --full-rescore-top-k 4 \
  --full-rescore-random-k 1
```

### 3) Ver relatório de crescimento

```bash
python -m mycelium report --seed 101 --state-dir .mycelium_state
```

### 4) Usar kill-switch

```bash
touch .mycelium_state/KILL
```

Na próxima verificação do loop, a execução para de forma limpa.

### 5) Fazer rollback

```bash
python -m mycelium rollback --seed 101 --state-dir .mycelium_state --round 10
```

O rollback resolve automaticamente checkpoints salvos em JSON ou pickle.

### 6) Usar persistência binária opcional

Por padrão o projeto continua em `json` por compatibilidade e inspeção humana, mas agora é possível usar `pickle` para reduzir overhead de persistência quando o workload faz muitos flushes/checkpoints.

```bash
python -m mycelium run \
  --seed 101 \
  --state-dir .mycelium_state \
  --rounds 100 \
  --persistence-backend pickle
```

Arquivos gerados conforme o backend:

- estado: `state.json` ou `state.pkl`
- checkpoints: `checkpoints/round-XXXXX.json` ou `checkpoints/round-XXXXX.pkl`

Leitura honesta do benchmark desta sessão:

- no perfil default atual, `json` ainda ficou ligeiramente mais rápido no script simples de throughput;
- em um cenário de persistência agressiva (`state_save_every=1` e `checkpoint_every=1`), `pickle` subiu de **~49,13 rounds/s** para **~82,64 rounds/s** na média de 5 execuções;
- por isso o backend binário foi mantido como **opcional** e o guarda do `self-improve` passou a poder escolhê-lo quando ele realmente melhora o cenário medido.

## Modo de auto melhoria

Comando principal:

```bash
python -m mycelium self-improve --seed 101 --state-dir .mycelium_state --cycles 1 --rounds-per-cycle 20
```

Execução com orçamento de tempo:

```bash
python -m mycelium self-improve \
  --seed 101 \
  --state-dir .mycelium_state \
  --cycles 999999 \
  --time-budget-seconds 120 \
  --guard-workers 4
```

Modo contínuo em daemon/loop:

```bash
python -m mycelium self-improve-daemon \
  --seed 101 \
  --state-dir .mycelium_state \
  --rounds-per-cycle 20 \
  --sleep-seconds 5 \
  --guard-workers 4
```

O modo `self-improve`:

- roda evolução normal por ciclo;
- gera candidatos automáticos de tuning, incluindo backend de persistência e cadência de save/checkpoint;
- paraleliza o benchmark do guarda por processos;
- compara baseline x candidato com as mesmas seeds;
- aplica apenas candidatos que passam no guarda anti-regressão;
- reverte a mudança se a suíte de testes falhar.

Por padrão, o guarda usa um benchmark mais conservador:

- `30` rodadas por candidato
- seeds `101,103,107,109,113`
- bloqueio de regressão em score, exatidão, solves e capability signal

Arquivos persistidos quando um candidato é aceito:

- `mycelium/generated/active_variants.py`
- `mycelium/generated/default_profile.py`

Relatórios e status:

- `.mycelium_self_improve/latest.json`
- `.mycelium_self_improve/self-improve-<timestamp>.json`
- `.mycelium_self_improve/daemon.status.json`

O daemon para quando encontra o mesmo kill-switch já usado pelo engine:

```bash
touch .mycelium_state/KILL
```

Detalhes do guarda e do fluxo:

- `docs/SELF_IMPROVEMENT.md`

## Modo aceleração

### Auto-acelerar o próprio MYCELIUM

```bash
python -m mycelium accelerate --target self
```

Isso mede variantes equivalentes de uma rotina interna, escolhe a mais rápida e grava o resultado em:

```text
mycelium/generated/active_variants.py
```

Ou seja: a decisão volta para o **código-fonte real** e passa a valer nas próximas execuções.

### Acelerar um alvo externo em Python

Existe um exemplo pronto em:

```text
examples/accelerate_target.py
```

Rode:

```bash
python -m mycelium accelerate --target examples/accelerate_target.py
```

O contrato esperado é:

- `ACTIVE_VARIANT = "..."`
- `BENCHMARK_SPEC = {...}` com baseline, variantes e casos
- funções candidatas com saídas exatamente idênticas ao baseline

Se uma variante alterar a saída, ela é descartada.

## Mapeamento rápido da especificação para o código

| Especificação | Implementação atual |
|---|---|
| Sem LLM | projeto todo em Python puro |
| Critérios aleatórios | `ChallengeFactory` cria oráculos ocultos procedurais |
| Seed prima | `prime.py` + `Config.__post_init__` |
| Evolução estrutural | `dsl.py`, `mutate`, `crossover` |
| Torneio ímpar | `tournament_size` ímpar obrigatório |
| Fase por `i` | seleção normal / neutra / invertida por família |
| Vigor por `e` | decaimento exponencial por profundidade de linhagem |
| Clima | multiplicadores leves por `π` ou `1/2.967` |
| Extinção familiar | `_extinguish_one_family` |
| Diáspora dos 7 | redistribuição de 3 reprodutores + 4 doadores |
| Fusão entre extremos | `_apply_fusion_rule` |
| Ladrão / Clérigo / Artista | `_apply_character_events` |
| Kill-switch | arquivo `KILL` |
| Log append-only | `audit.log.jsonl` |
| Rollback | checkpoints em `checkpoints/` |
| Medição honesta de crescimento | `growth_report()` |

## Performance

Para um resumo das otimizações e benchmark observado nesta sessão, veja:

- `docs/PERFORMANCE.md`

Benchmark rápido reproduzível:

```bash
python examples/benchmark_runtime.py
```

O script agora compara também um perfil `default_binary_optional` com `--persistence-backend pickle`.

Comparação multi-seed de velocidade x qualidade:

```bash
python examples/benchmark_quality.py
```

Histórico consolidado das mudanças:

- `CHANGES.md`

## Testes

```bash
python -m unittest discover -s tests -v
```

## Decisão de design importante

A especificação manda extinguir uma família por rodada. Para o loop não colapsar para zero famílias, este MVP faz uma **interpretação operacional explícita**:

- uma família é extinta;
- 7 sobreviventes entram em diáspora;
- uma **família fresca** nasce para repor o ecossistema.

Essa decisão está documentada em `docs/ARCHITECTURE.md` e deve ser tratada como hipótese de prototipagem, não como axioma final.

## Próximos passos sugeridos para a versão GitHub

1. adicionar CI com GitHub Actions;
2. fixar smoke-tests por seed;
3. gerar dashboards CSV/HTML de evolução;
4. adicionar sandbox por subprocesso com limites do SO;
5. comparar políticas em experimento pareado multi-seed;
6. criar uma camada de adapters para acelerar projetos reais por linguagem.
