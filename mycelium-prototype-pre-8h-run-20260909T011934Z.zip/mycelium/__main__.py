from __future__ import annotations

import argparse
import json
from pathlib import Path

from .acceleration import accelerate_external, accelerate_self
from .config import Config
from .engine import MyceliumEngine
from .runtime_profile import load_default_profile
from .self_improve import SelfImprover, build_guard_from_args
from .state import load_state


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="MYCELIUM prototype")
    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser("init", help="initialize persistent state")
    _add_common_args(init_parser)

    run_parser = subparsers.add_parser("run", help="run improvement rounds")
    _add_common_args(run_parser)
    run_parser.add_argument("--rounds", type=int, default=10)

    report_parser = subparsers.add_parser("report", help="print current growth report")
    _add_common_args(report_parser)

    rollback_parser = subparsers.add_parser("rollback", help="restore a checkpointed round")
    _add_common_args(rollback_parser)
    rollback_parser.add_argument("--round", dest="rollback_round", type=int, required=True)

    accelerate_parser = subparsers.add_parser("accelerate", help="benchmark and apply faster equivalent variants")
    accelerate_parser.add_argument("--target", default="self", help="self or path/to/module.py")

    self_improve_parser = subparsers.add_parser("self-improve", help="run guarded self-improvement cycles")
    _add_common_args(self_improve_parser)
    self_improve_parser.add_argument("--cycles", type=int, default=1)
    self_improve_parser.add_argument("--rounds-per-cycle", type=int, default=20)
    _add_self_improve_args(self_improve_parser)

    daemon_parser = subparsers.add_parser("self-improve-daemon", help="run self-improvement continuously until kill-switch or limit")
    _add_common_args(daemon_parser)
    daemon_parser.add_argument("--rounds-per-cycle", type=int, default=20)
    daemon_parser.add_argument("--sleep-seconds", type=float, default=0.0)
    daemon_parser.add_argument("--max-cycles", type=int, default=None)
    _add_self_improve_args(daemon_parser)

    return parser


def _add_common_args(parser: argparse.ArgumentParser) -> None:
    profile = load_default_profile()
    parser.add_argument("--seed", type=int, default=101)
    parser.add_argument("--state-dir", default=".mycelium_state")
    parser.add_argument("--family-count", type=int, default=profile["family_count"])
    parser.add_argument("--family-size", type=int, default=profile["family_size"])
    parser.add_argument("--challenges-per-round", type=int, default=profile["challenges_per_round"])
    parser.add_argument("--train-cases", type=int, default=profile["train_cases"])
    parser.add_argument("--test-cases", type=int, default=profile["test_cases"])
    parser.add_argument("--initial-difficulty", type=int, default=profile["initial_difficulty"])
    parser.add_argument("--max-program-depth", type=int, default=profile["max_program_depth"])
    parser.add_argument("--max-program-nodes", type=int, default=profile["max_program_nodes"])
    parser.add_argument("--max-abs-value", type=int, default=profile["max_abs_value"])
    parser.add_argument("--max-eval-steps", type=int, default=profile["max_eval_steps"])
    parser.add_argument("--max-macros", type=int, default=profile["max_macros"])
    parser.add_argument("--checkpoint-every", type=int, default=profile["checkpoint_every"])
    parser.add_argument("--state-save-every", type=int, default=profile["state_save_every"])
    parser.add_argument("--probe-challenges", type=int, default=profile["probe_challenges"])
    parser.add_argument("--probe-train-cases", type=int, default=profile["probe_train_cases"])
    parser.add_argument("--probe-test-cases", type=int, default=profile["probe_test_cases"])
    parser.add_argument("--full-rescore-top-k", type=int, default=profile["full_rescore_top_k"])
    parser.add_argument("--full-rescore-random-k", type=int, default=profile["full_rescore_random_k"])
    parser.add_argument("--persistence-backend", choices=["json", "pickle"], default=profile["persistence_backend"])
    parser.add_argument("--climate-weight", type=float, default=profile["climate_weight"])
    parser.add_argument("--novelty-weight", type=float, default=profile["novelty_weight"])
    parser.add_argument("--macro-potential-weight", type=float, default=profile["macro_potential_weight"])
    parser.add_argument("--transfer-weight", type=float, default=profile["transfer_weight"])
    parser.add_argument("--macro-support-threshold", type=int, default=profile["macro_support_threshold"])
    parser.add_argument("--macro-transfer-threshold", type=float, default=profile["macro_transfer_threshold"])
    parser.add_argument("--macro-retire-rounds", type=int, default=profile["macro_retire_rounds"])
    parser.add_argument("--compositional-challenge-rate", type=float, default=profile["compositional_challenge_rate"])
    parser.add_argument("--niche-probe-count", type=int, default=profile["niche_probe_count"])
    parser.add_argument("--frontier-archive-limit", type=int, default=profile["frontier_archive_limit"])
    parser.add_argument("--frontier-window", type=int, default=profile["frontier_window"])
    parser.add_argument("--gene-splice-rate", type=float, default=profile["gene_splice_rate"])
    parser.add_argument("--shrink-mutation-rate", type=float, default=profile["shrink_mutation_rate"])


def _add_self_improve_args(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--benchmark-rounds", type=int, default=30)
    parser.add_argument("--benchmark-seeds", default="101,103,107,109,113")
    parser.add_argument("--guard-workers", type=int, default=4)
    parser.add_argument("--time-budget-seconds", type=int, default=None)
    parser.add_argument("--min-speedup-ratio", type=float, default=0.01)
    parser.add_argument("--max-best-score-drop", type=float, default=0.0)
    parser.add_argument("--max-exact-rate-drop", type=float, default=0.0)
    parser.add_argument("--max-solved-drop", type=float, default=0.0)
    parser.add_argument("--max-capability-drop", type=float, default=0.0)
    parser.add_argument("--max-frontier-drop", type=float, default=0.35)
    parser.add_argument("--skip-tests", action="store_true")
    parser.add_argument("--project-root", default=".")


def config_from_args(args: argparse.Namespace) -> Config:
    return Config(
        seed=args.seed,
        state_dir=args.state_dir,
        family_count=args.family_count,
        family_size=args.family_size,
        challenges_per_round=args.challenges_per_round,
        train_cases=args.train_cases,
        test_cases=args.test_cases,
        initial_difficulty=args.initial_difficulty,
        max_program_depth=args.max_program_depth,
        max_program_nodes=args.max_program_nodes,
        max_abs_value=args.max_abs_value,
        max_eval_steps=args.max_eval_steps,
        max_macros=args.max_macros,
        checkpoint_every=args.checkpoint_every,
        state_save_every=args.state_save_every,
        probe_challenges=args.probe_challenges,
        probe_train_cases=args.probe_train_cases,
        probe_test_cases=args.probe_test_cases,
        full_rescore_top_k=args.full_rescore_top_k,
        full_rescore_random_k=args.full_rescore_random_k,
        persistence_backend=args.persistence_backend,
        climate_weight=args.climate_weight,
        novelty_weight=args.novelty_weight,
        macro_potential_weight=args.macro_potential_weight,
        transfer_weight=args.transfer_weight,
        macro_support_threshold=args.macro_support_threshold,
        macro_transfer_threshold=args.macro_transfer_threshold,
        macro_retire_rounds=args.macro_retire_rounds,
        compositional_challenge_rate=args.compositional_challenge_rate,
        niche_probe_count=args.niche_probe_count,
        frontier_archive_limit=args.frontier_archive_limit,
        frontier_window=args.frontier_window,
        gene_splice_rate=args.gene_splice_rate,
        shrink_mutation_rate=args.shrink_mutation_rate,
    )


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "accelerate":
        if args.target == "self":
            outcome = accelerate_self(Path.cwd())
        else:
            outcome = accelerate_external(Path(args.target))
        print(json.dumps({
            "module": outcome.module_path,
            "baseline": outcome.baseline,
            "best_variant": outcome.best_variant,
            "timings": [{"variant": item.variant, "seconds": item.seconds} for item in outcome.timings],
        }, indent=2))
        return

    config = config_from_args(args)

    if args.command == "self-improve":
        improver = SelfImprover(Path(args.project_root).resolve(), config, build_guard_from_args(args))
        summary = improver.run(
            args.cycles,
            args.rounds_per_cycle,
            time_budget_seconds=args.time_budget_seconds,
        )
        print(json.dumps(summary.to_dict(), indent=2))
        return

    if args.command == "self-improve-daemon":
        improver = SelfImprover(Path(args.project_root).resolve(), config, build_guard_from_args(args))
        summary = improver.run_daemon(
            args.rounds_per_cycle,
            time_budget_seconds=args.time_budget_seconds,
            sleep_seconds=args.sleep_seconds,
            max_cycles=args.max_cycles,
        )
        print(json.dumps(summary.to_dict(), indent=2))
        return

    engine = MyceliumEngine(config)

    if args.command == "init":
        state = engine.init_state()
        print(json.dumps({"state_dir": config.state_dir, "families": len(state.families), "round": state.round_index}, indent=2))
        return

    if args.command == "run":
        summary = engine.run(args.rounds)
        print(json.dumps({
            "rounds_executed": summary.rounds_executed,
            "stopped_by_kill_switch": summary.stopped_by_kill_switch,
            "best_score": summary.best_score,
            "frontier_difficulty": summary.frontier_difficulty,
            "growth_regime": summary.growth_regime,
        }, indent=2))
        return

    if args.command == "report":
        state = load_state(Path(config.state_dir))
        report = engine.growth_report(state)
        print(json.dumps(report, indent=2))
        return

    if args.command == "rollback":
        state = engine.rollback(args.rollback_round)
        print(json.dumps({"round": state.round_index, "state_dir": config.state_dir}, indent=2))
        return


if __name__ == "__main__":
    main()
