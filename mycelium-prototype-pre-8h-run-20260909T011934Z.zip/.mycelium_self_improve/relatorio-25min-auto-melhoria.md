# Relatório escrito — rodada padrão de auto melhoria por 25 minutos

Data da execução: 2026-09-08  
Projeto: `/home/user/mycelium-prototype`

## 1. Resumo executivo

Foi executada uma rodada padrão de auto melhoria com orçamento de **25 minutos** (`1500s`).

Resultado geral:

- **66 ciclos** concluídos
- **15 ciclos aprovados** pelo guarda anti-regressão
- **51 ciclos rejeitados**
- **1320 rounds evolutivos** executados no total (`66 x 20`)
- parada por **fim do orçamento de tempo**, não por kill-switch

### Conclusão principal

Tudo o que foi aprovado nessa janela foi uma única classe de mudança:

- **troca do backend de persistência entre `json` e `pickle`**

Nenhuma outra modificação de perfil foi consolidada. Em particular:

- **não houve mudança de `active_variant`**; permaneceu `pythonic`
- **não houve mudança em família, desafios, probes, rescore ou clima**
- a única diferença final no `default_profile` foi:
  - `persistence_backend: 'json' -> 'pickle'`

---

## 2. O que exatamente foi aprovado

Os 15 ciclos aprovados alternaram apenas o campo `persistence_backend`.

### Aprovações para `pickle`

| Ciclo | Mudança | Baseline (r/s) | Candidato (r/s) | Ganho |
|---|---|---:|---:|---:|
| 1 | json -> pickle | 54.04 | 57.06 | +5.59% |
| 7 | json -> pickle | 51.38 | 58.02 | +12.92% |
| 12 | json -> pickle | 55.22 | 57.12 | +3.45% |
| 14 | json -> pickle | 54.23 | 58.57 | +8.00% |
| 20 | json -> pickle | 53.13 | 54.49 | +2.55% |
| 24 | json -> pickle | 53.93 | 54.83 | +1.67% |
| 32 | json -> pickle | 52.40 | 57.83 | +10.37% |
| 62 | json -> pickle | 53.95 | 55.17 | +2.25% |

### Aprovações para `json`

| Ciclo | Mudança | Baseline (r/s) | Candidato (r/s) | Ganho |
|---|---|---:|---:|---:|
| 6 | pickle -> json | 49.63 | 53.49 | +7.78% |
| 9 | pickle -> json | 52.77 | 53.57 | +1.51% |
| 13 | pickle -> json | 52.62 | 54.86 | +4.25% |
| 18 | pickle -> json | 50.36 | 53.56 | +6.35% |
| 22 | pickle -> json | 51.88 | 56.05 | +8.03% |
| 30 | pickle -> json | 54.33 | 55.79 | +2.69% |
| 60 | pickle -> json | 53.02 | 54.15 | +2.14% |

### Leitura correta dessas aprovações

Essas aprovações mostram que o benchmark do guarda ficou **bem apertado e sujeito a ruído de medição**, porque as duas opções (`json` e `pickle`) se alternaram várias vezes ao longo dos 66 ciclos.

Portanto, a leitura correta não é “pickle sempre vence” nem “json sempre vence”. A leitura correta é:

- o guarda encontrou **ganhos locais medidos** em ambos os sentidos;
- no fechamento da janela de 25 minutos, o **estado final aprovado** ficou em `pickle`.

---

## 3. Houve melhoria quantitativa?

## Sim, houve — mas ela é específica ao backend de persistência

A melhor forma de medir o efeito líquido final é comparar o perfil atual final em duas condições idênticas, mudando apenas o backend.

### Comparação pós-execução, com o perfil final atual

- `json`: **90.05 rounds/s**
- `pickle`: **98.05 rounds/s**

### Ganho líquido observado

- **+8.88%** para `pickle` sobre `json`

Essa é a melhor estimativa do efeito prático final consolidado para o estado em que o projeto terminou.

### Observação importante

Os números internos do guarda durante o `self-improve` ficaram na faixa de ~50–58 rounds/s porque o guarda mede várias execuções em paralelo, o que introduz contenção de CPU. Por isso:

- os números do guarda servem para **decisão relativa**;
- os números de benchmark isolado servem melhor como **headline de throughput real**.

---

## 4. Houve melhoria quantitativa em qualidade?

**Não foi observada melhoria quantitativa de qualidade nas mudanças aprovadas.**

E isso não é um problema neste caso, porque o guarda foi desenhado justamente para aceitar ganho de throughput **sem degradar** as métricas protegidas.

Nas aprovações, as métricas de qualidade permaneceram preservadas dentro das tolerâncias:

- `best_score_mean`
- `best_exact_rate_mean`
- `solved_by_best_mean`
- `capability_signal_mean`
- `frontier_difficulty_mean`

Então a conclusão correta é:

- houve **melhoria operacional de throughput**;
- **não houve regressão de qualidade**;
- a melhoria não veio de mudar a inteligência do processo evolutivo, e sim do custo de persistir estado.

---

## 5. Isso vai impactar as rodadas futuras?

## Sim, mas principalmente em performance operacional

### Impacto que **vai** existir

Como `mycelium/generated/default_profile.py` foi atualizado para:

- `persistence_backend = 'pickle'`

então, daqui para frente, execuções que usem o perfil default e **não sobrescrevam** esse campo vão herdar esse backend.

Na prática, isso afeta futuras rodadas assim:

1. **Novas execuções padrão** tenderão a usar `pickle` por default.
2. **Novos arquivos de estado** tenderão a ser gravados como `state.pkl`.
3. **Novos checkpoints** tenderão a ser gravados como `.pkl`.
4. Em cenários onde há custo real de persistência, isso deve permitir **mais rounds por unidade de tempo**.

### Impacto que **não** deve existir

A lógica evolutiva em si não foi alterada. Portanto, essa aprovação:

- **não muda** as regras de seleção;
- **não muda** o gerador de desafios;
- **não muda** a DSL;
- **não muda** os parâmetros populacionais;
- **não muda** o `active_variant` do agregador.

Ou seja:

- **não deve mudar o comportamento algorítmico por rodada**;
- **deve mudar o custo operacional entre rodadas**, especialmente em I/O/serialização.

### Interpretação prática

Se você medir “o que acontece dentro de uma rodada”, a tendência é **quase nenhum impacto qualitativo**.

Se você medir “quantas rodadas cabem em X minutos/horas”, aí sim existe impacto potencial relevante, porque a persistência mais barata reduz overhead acumulado.

---

## 6. Estado final consolidado após os 25 minutos

- `active_variant`: `pythonic`
- perfil default final:
  - `family_count = 7`
  - `family_size = 11`
  - `challenges_per_round = 3`
  - `train_cases = 8`
  - `test_cases = 16`
  - `probe_challenges = 2`
  - `probe_train_cases = 2`
  - `probe_test_cases = 4`
  - `full_rescore_top_k = 4`
  - `full_rescore_random_k = 1`
  - `checkpoint_every = 15`
  - `state_save_every = 15`
  - `persistence_backend = 'pickle'`

Resumo objetivo:

- o sistema **não descobriu um novo regime evolutivo**;
- ele **não aprovou novos parâmetros populacionais**;
- ele **não aprovou nova variante de código ativo**;
- ele **aprovou apenas a escolha operacional do backend de persistência**;
- o fechamento final favoreceu **`pickle`**.

---

## 7. Resposta curta à sua pergunta

### Tudo que foi aprovado

Somente trocas de:

- `persistence_backend: json <-> pickle`

### Teve melhoria quantitativa?

- **Sim**, na dimensão de throughput/persistência.
- Comparação final mais confiável após a execução:
  - `json`: **90.05 rounds/s**
  - `pickle`: **98.05 rounds/s**
  - ganho final observado: **+8.88%** para `pickle`

### Vai impactar as rodadas futuras?

- **Sim**, porque o default do projeto agora ficou em `pickle`.
- O impacto esperado é principalmente:
  - **menos overhead de persistência**;
  - **mais rounds por tempo de execução** em cenários parecidos.
- **Não** deve alterar de forma material a qualidade por rodada nem a lógica evolutiva, porque essas partes não foram modificadas.

---

## 8. Artefatos desta execução

- resumo da execução:
  - `.mycelium_self_improve/manual-25min-summary.json`
- relatório bruto completo:
  - `.mycelium_self_improve/self-improve-20260908T224311Z.json`
- ponteiro do último relatório:
  - `.mycelium_self_improve/latest.json`
- status final:
  - `.mycelium_self_improve/daemon.status.json`
